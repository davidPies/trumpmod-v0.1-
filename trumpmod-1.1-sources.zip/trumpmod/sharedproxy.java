package trumpmod;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class sharedproxy {

	@EventHandler
    public void pre(FMLPreInitializationEvent e){
    }
	@EventHandler
    public void init(FMLInitializationEvent e){
    }
	public void registerRenderers() {
		
	}
	public void registerItemColorHandler(Item item) {
	}
}
