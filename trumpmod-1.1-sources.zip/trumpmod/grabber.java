package trumpmod;

import net.minecraft.item.Item;

public class grabber extends Item{
	public grabber(){
		this.func_77637_a(tabs.trumpmodtab);
		this.func_77655_b("grabber");
		this.func_77625_d(16);
		
	}
}
