package trumpmod;

import net.minecraft.item.Item;

public class hair2 extends Item{
	public hair2(){
		this.func_77637_a(tabs.trumpmodtab);
		this.func_77655_b("hair2");
		this.func_77625_d(64);
		
	}
}
