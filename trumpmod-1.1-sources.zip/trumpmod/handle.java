package trumpmod;

import net.minecraft.item.Item;

public class handle extends Item{
	public handle(){
		this.func_77637_a(tabs.trumpmodtab);
		this.func_77655_b("handle");
		this.func_77625_d(16);
		
	}
}
